var searchData=
[
  ['getpoint_18',['getpoint',['../namespaceperson__command.html#ae5d92a196fa4e778013d21798367a229',1,'person_command']]],
  ['gotopoint_19',['gotopoint',['../namespaceperson__command.html#a62417e7e61668089a2cc37aa1b9ac0f1',1,'person_command']]]
];
