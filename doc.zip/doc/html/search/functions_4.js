var searchData=
[
  ['sub_5fcallback_22',['sub_callback',['../namespaceperson__command.html#af62d365797a400cb75113e894e3caa3e',1,'person_command']]],
  ['sub_5fcallback_5fcommand_23',['sub_callback_command',['../namespaceperson__command.html#ae960801be5e9640c7c4a6541928644fb',1,'person_command']]]
];
